{-# LANGUAGE DataKinds          #-}
{-# LANGUAGE DeriveAnyClass     #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE FlexibleContexts   #-}
{-# LANGUAGE NamedFieldPuns     #-}
{-# LANGUAGE OverloadedStrings  #-}
{-# LANGUAGE TypeFamilies       #-}

{- Cardano wallet implementation for the emulator.
-}
module Ledger.CardanoWallet(
    MockWallet(..),
    -- * Enumerating wallets
    WalletNumber(..),
    fromWalletNumber,
    toWalletNumber,
    knownMockWallets,
    knownMockWallet,
    fromSeed,
    fromSeed',
    -- ** Keys
    paymentPrivateKey,
    paymentPubKeyHash,
    paymentPubKey
    ) where

import Cardano.Address.Derivation (XPrv)
import Cardano.Crypto.Wallet qualified as Crypto
import Cardano.Wallet.Primitive.Types qualified as CW
import Codec.Serialise (serialise)
import Crypto.Hash qualified as Crypto
import Data.Aeson (FromJSON, ToJSON)
import Data.Aeson.Extras (encodeByteString)
import Data.ByteString qualified as BS
import Data.ByteString.Lazy qualified as BSL
import Data.Hashable (Hashable (..))
import Data.List (findIndex)
import Data.Maybe (fromMaybe)
import Data.Text qualified as T
import GHC.Generics (Generic)
import Ledger (PaymentPrivateKey (PaymentPrivateKey), PaymentPubKey (PaymentPubKey, unPaymentPubKey),
               PaymentPubKeyHash (PaymentPubKeyHash))
import Ledger.Crypto (PubKey (..))
import Ledger.Crypto qualified as Crypto
import Plutus.V1.Ledger.Bytes (LedgerBytes (getLedgerBytes))
import Servant.API (FromHttpApiData, ToHttpApiData)

newtype MockPrivateKey = MockPrivateKey { unMockPrivateKey :: XPrv }

instance Show MockPrivateKey where
    show = T.unpack . encodeByteString . Crypto.unXPrv . unMockPrivateKey
instance Eq MockPrivateKey where
    (MockPrivateKey l) == (MockPrivateKey r) = Crypto.unXPrv l == Crypto.unXPrv r
instance Ord MockPrivateKey where
    compare (MockPrivateKey l) (MockPrivateKey r) = compare (Crypto.unXPrv l) (Crypto.unXPrv r)
instance Hashable MockPrivateKey where
    hashWithSalt i = hashWithSalt i . Crypto.unXPrv . unMockPrivateKey

-- | Emulated wallet with a key and a passphrase
data MockWallet =
    MockWallet
        { mwWalletId   :: CW.WalletId
        , mwPaymentKey :: MockPrivateKey
        , mwStakeKey   :: Maybe MockPrivateKey
        }
        deriving Show

-- | Wrapper for config files and APIs
newtype WalletNumber = WalletNumber { getWallet :: Integer }
    deriving (Show, Eq, Ord, Generic)
    deriving newtype (ToHttpApiData, FromHttpApiData)
    deriving anyclass (FromJSON, ToJSON)

fromWalletNumber :: WalletNumber -> MockWallet
fromWalletNumber (WalletNumber i) = fromSeed' (BSL.toStrict $ serialise i)

fromSeed :: BS.ByteString -> Crypto.Passphrase -> MockWallet
fromSeed bs passPhrase = fromSeedInternal (flip Crypto.generateFromSeed passPhrase) bs

fromSeed' :: BS.ByteString -> MockWallet
fromSeed' = fromSeedInternal Crypto.generateFromSeed'

fromSeedInternal :: (BS.ByteString -> Crypto.XPrv) -> BS.ByteString -> MockWallet
fromSeedInternal seedGen bs = MockWallet{mwWalletId, mwPaymentKey, mwStakeKey} where
    missing = max 0 (32 - BS.length bs)
    bs' = bs <> BS.replicate missing 0
    k = seedGen bs'
    mwWalletId = CW.WalletId
        $ fromMaybe (error "Ledger.CardanoWallet.fromSeed: digestFromByteString")
        $ Crypto.digestFromByteString
        $ Crypto.hashWith Crypto.Blake2b_160
        $ getLedgerBytes
        $ getPubKey
        $ Crypto.toPublicKey k
    mwPaymentKey = MockPrivateKey k
    mwStakeKey = Nothing

toWalletNumber :: MockWallet -> WalletNumber
toWalletNumber MockWallet{mwWalletId=w} =
    maybe (error "Ledger.CardanoWallet.toWalletNumber: not a known wallet")
          (WalletNumber . toInteger . succ)
          $ findIndex ((==) w . mwWalletId) knownMockWallets

-- | The wallets used in mockchain simulations by default. There are
--   ten wallets by default.
knownMockWallets :: [MockWallet]
knownMockWallets = fromWalletNumber . WalletNumber <$> [1..10]

-- | Get a known wallet from an @Integer@ indexed from 1 to 10.
knownMockWallet :: Integer -> MockWallet
knownMockWallet = (knownMockWallets !!) . pred . fromInteger

-- | Mock wallet's private key
paymentPrivateKey :: MockWallet -> PaymentPrivateKey
paymentPrivateKey = PaymentPrivateKey . unMockPrivateKey . mwPaymentKey

-- | The mock wallet's public key hash
paymentPubKeyHash :: MockWallet -> PaymentPubKeyHash
paymentPubKeyHash = PaymentPubKeyHash . Crypto.pubKeyHash . unPaymentPubKey . paymentPubKey

-- | The mock wallet's payment public key
paymentPubKey :: MockWallet -> PaymentPubKey
paymentPubKey = PaymentPubKey . Crypto.toPublicKey . unMockPrivateKey . mwPaymentKey
