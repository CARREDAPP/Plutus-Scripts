{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE MonoLocalBinds   #-}
module Plutus.Contract.Constraints(module Constraints) where

import Ledger.Constraints as Constraints
