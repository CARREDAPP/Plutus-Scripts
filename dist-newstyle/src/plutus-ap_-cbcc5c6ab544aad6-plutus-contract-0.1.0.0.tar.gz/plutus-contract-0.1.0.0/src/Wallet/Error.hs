module Wallet.Error(
    module Error
    ) where

import Wallet.Emulator.Error as Error

